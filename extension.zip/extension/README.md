# USITC
USITC ArkCase Extension

##### To be removed
.gitkeep files were created as placeholders to allow checking in the folder structure. Please remove when some files are actually added to each directory.
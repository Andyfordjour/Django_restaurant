package ext.training.acm.plugins.comment.model;

public interface ExtCommentConstants
{
    String OBJECT_TYPE = "COMMENT";
    String EVENT_BASE_TYPE = "ext.training.acm.plugins.comment.event";
    String EVENT_TYPE_CREATE = "create";
    String EVENT_TYPE_UPDATE = "update";
    String EVENT_TYPE_DELETE = "delete";
}

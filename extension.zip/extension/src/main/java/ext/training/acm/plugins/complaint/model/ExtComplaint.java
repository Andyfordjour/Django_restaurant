package ext.training.acm.plugins.complaint.model;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.armedia.acm.plugins.complaint.model.Complaint;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.voodoodyne.jackson.jsog.JSOGGenerator;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "acm_complaint")
@DiscriminatorValue("ext.training.acm.plugins.complaint.model.ExtComplaint")
@JsonIdentityInfo(generator = JSOGGenerator.class)
@Getter
@Setter
public class ExtComplaint extends Complaint
{
    @Column(name = "ext_complaint_subtitle")
    private String subtitle;
}

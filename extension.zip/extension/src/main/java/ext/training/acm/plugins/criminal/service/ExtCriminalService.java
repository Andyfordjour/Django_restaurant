package ext.training.acm.plugins.criminal.service;

import ext.training.acm.plugins.criminal.model.ExtCriminal;

/**
 * Business-layer contract for working with {@link ExtCriminal} records.
 * <p>
 * Kept as a separate interface (implemented by {@link ExtCriminalServiceImpl})
 * so the REST controller depends on behavior, not on the persistence
 * details underneath it - matching the same pattern used by the Complaint
 * and Comment modules in this extension.
 */
public interface ExtCriminalService
{
    /**
     * Creates a new Criminal (when {@code criminal.getId()} is {@code null})
     * or updates an existing one otherwise.
     *
     * @param criminal
     *            the Criminal to save
     * @return the saved Criminal, including any generated id/timestamps
     */
    ExtCriminal save(ExtCriminal criminal);

    /**
     * Looks up a Criminal by its id.
     *
     * @param id
     *            the Criminal's id
     * @return the matching Criminal, or {@code null} if none exists
     */
    ExtCriminal findById(Long id);

    /**
     * Deletes the Criminal with the given id.
     *
     * @param id
     *            the Criminal's id
     */
    void deleteById(Long id);
}

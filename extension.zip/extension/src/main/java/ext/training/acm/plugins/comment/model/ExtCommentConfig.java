package ext.training.acm.plugins.comment.model;

import org.springframework.beans.factory.annotation.Value;

import com.armedia.acm.pluginmanager.service.AcmPluginConfigBean;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ExtCommentConfig implements AcmPluginConfigBean
{
    @JsonProperty("comment.plugin.search.tree.filter")
    @Value("${comment.plugin.search.tree.filter}")
    private String searchTreeFilter;

    @Value("${comment.plugin.search.tree.sort}")
    private String searchTreeSort;

    @JsonProperty("comment.plugin.search.tree.searchQuery")
    @Value("${comment.plugin.search.tree.searchQuery}")
    private String searchTreeSearchQuery;

    @Override
    public String getSearchTreeFilter()
    {
        return searchTreeFilter;
    }

    @Override
    public String getSearchTreeSort()
    {
        return searchTreeSort;
    }

    @Override
    public String getSearchTreeQuery()
    {
        return searchTreeSearchQuery;
    }
}

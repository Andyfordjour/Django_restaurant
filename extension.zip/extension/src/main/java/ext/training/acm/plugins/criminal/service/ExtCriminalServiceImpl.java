package ext.training.acm.plugins.criminal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ext.training.acm.plugins.criminal.dao.ExtCriminalDao;
import ext.training.acm.plugins.criminal.model.ExtCriminal;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * Default implementation of {@link ExtCriminalService}.
 * <p>
 * Thin pass-through to {@link ExtCriminalDao} - all the actual persistence
 * logic lives in the DAO/JPA layer; this class just exposes it through the
 * service contract that the REST controller depends on.
 */
@Getter
@Setter
@Service("extCriminalService")
@RequiredArgsConstructor
public class ExtCriminalServiceImpl implements ExtCriminalService
{
    @Autowired
    private ExtCriminalDao extCriminalDao;

    /** {@inheritDoc} */
    @Override
    public ExtCriminal save(ExtCriminal criminal)
    {
        return getExtCriminalDao().save(criminal);
    }

    /** {@inheritDoc} */
    @Override
    public ExtCriminal findById(Long id)
    {
        return getExtCriminalDao().find(id);
    }

    /** {@inheritDoc} */
    @Override
    public void deleteById(Long id)
    {
        getExtCriminalDao().deleteById(id);
    }
}

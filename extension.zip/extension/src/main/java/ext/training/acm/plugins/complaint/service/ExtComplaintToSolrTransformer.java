package ext.training.acm.plugins.complaint.service;

import com.armedia.acm.plugins.complaint.model.Complaint;
import com.armedia.acm.plugins.complaint.service.ComplaintToSolrTransformer;
import com.armedia.acm.services.search.model.solr.SolrAdvancedSearchDocument;

import ext.training.acm.plugins.complaint.model.ExtComplaint;

public class ExtComplaintToSolrTransformer extends ComplaintToSolrTransformer
{
    @Override
    public SolrAdvancedSearchDocument toSolrAdvancedSearch(Complaint in)
    {
        SolrAdvancedSearchDocument solr = super.toSolrAdvancedSearch(in);
        solr.setAdditionalProperty("subtitle_lcs", ((ExtComplaint) in).getSubtitle());

        return solr;
    }

    @Override
    public boolean isAcmObjectTypeSupported(Class acmObjectType)
    {
        return ExtComplaint.class.equals(acmObjectType);
    }

    @Override
    public Class<?> getAcmObjectTypeSupported()
    {
        return ExtComplaint.class;
    }
}
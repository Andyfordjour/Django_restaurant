package ext.training.acm.plugins.criminal.web.api;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ext.training.acm.plugins.criminal.model.ExtCriminal;
import ext.training.acm.plugins.criminal.model.ExtCriminalConstants;
import ext.training.acm.plugins.criminal.model.ExtCriminalEvent;
import ext.training.acm.plugins.criminal.service.ExtCriminalService;
import lombok.Getter;
import lombok.Setter;

/**
 * REST endpoints for the Criminal module, mounted at
 * {@code /api/v1/plugin/ext/criminal}. Backs the Angular side's
 * {@code Criminals.InfoService} (save/get/delete calls).
 * <p>
 * Every create/update/delete also publishes an {@link ExtCriminalEvent} so
 * the record shows up in ACM's generic audit/history log (the Criminal
 * module's "History" tab).
 */
@RestController
@RequestMapping({ "/api/v1/plugin/ext/criminal" })
@Getter
@Setter
public class ExtCriminalAPIController implements ApplicationEventPublisherAware
{
    @Autowired
    private ExtCriminalService extCriminalService;

    private ApplicationEventPublisher applicationEventPublisher;

    /**
     * Creates or updates a Criminal. Whether this is a "create" or "update"
     * event (for audit purposes) is decided purely by whether the incoming
     * object already has an id - the New Criminal popup sends one without an
     * id, the Details tab sends one with an id.
     *
     * @param extCriminal
     *            the Criminal to save, from the request body
     * @param httpSession
     *            used only to read the caller's IP address for the audit event
     * @return the saved Criminal, including its generated id if this was a create
     */
    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ExtCriminal saveExtCriminal(@RequestBody ExtCriminal extCriminal, HttpSession httpSession)
    {
        String eventType = extCriminal.getId() == null ? ExtCriminalConstants.EVENT_TYPE_CREATE : ExtCriminalConstants.EVENT_TYPE_UPDATE;
        String ipAddress = (String) httpSession.getAttribute("acm_ip_address");

        extCriminal = getExtCriminalService().save(extCriminal);

        publishExtCriminalEvent(extCriminal, eventType, ipAddress);

        return extCriminal;
    }

    /**
     * Fetches a single Criminal by id. Used to load the Details tab and the
     * module header when a Criminal is selected in the tree.
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ExtCriminal findById(@PathVariable("id") Long id)
    {
        return getExtCriminalService().findById(id);
    }

    /**
     * Deletes a Criminal by id. The record is read first purely so its data
     * (title, etc.) can still be included on the "delete" audit event after
     * it's gone.
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public void deleteExtCriminalById(@PathVariable("id") Long id, HttpSession httpSession)
    {
        ExtCriminal extCriminal = getExtCriminalService().findById(id);

        String eventType = ExtCriminalConstants.EVENT_TYPE_DELETE;
        String ipAddress = (String) httpSession.getAttribute("acm_ip_address");

        getExtCriminalService().deleteById(id);

        publishExtCriminalEvent(extCriminal, eventType, ipAddress);
    }

    /** Required by {@link ApplicationEventPublisherAware}; Spring calls this automatically. */
    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher)
    {
        this.applicationEventPublisher = applicationEventPublisher;
    }

    /** Builds and publishes an {@link ExtCriminalEvent} for the audit/history log. */
    private void publishExtCriminalEvent(ExtCriminal extCriminal, String eventType, String ipAddress)
    {
        ExtCriminalEvent event = new ExtCriminalEvent(extCriminal, eventType, true, ipAddress);
        getApplicationEventPublisher().publishEvent(event);
    }
}

package ext.training.acm.plugins.criminal.service;

import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.ASSIGNEE_FIRST_NAME_LCS;
import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.ASSIGNEE_FULL_NAME_LCS;
import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.ASSIGNEE_ID_LCS;
import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.ASSIGNEE_LAST_NAME_LCS;
import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.STATUS_LCS;
import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.TITLE_PARSEABLE_LCS;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.armedia.acm.services.dataaccess.service.SearchAccessControlFields;
import com.armedia.acm.services.participants.utils.ParticipantUtils;
import com.armedia.acm.services.search.model.solr.SolrAdvancedSearchDocument;
import com.armedia.acm.services.search.service.AcmObjectToSolrDocTransformer;
import com.armedia.acm.services.users.dao.UserDao;
import com.armedia.acm.services.users.model.AcmUser;

import ext.training.acm.plugins.criminal.dao.ExtCriminalDao;
import ext.training.acm.plugins.criminal.model.ExtCriminal;
import ext.training.acm.plugins.criminal.model.ExtCriminalConstants;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * Converts an {@link ExtCriminal} JPA entity into the Solr document ACM
 * indexes it as, which is what powers the Criminal tree/list, the global
 * search box, and facet filtering for Criminal records.
 * <p>
 * The reindexing job calls {@link #getObjectsModifiedSince(Date, int, int)}
 * in batches, then {@link #toSolrAdvancedSearch(ExtCriminal)} for each one
 * to build its Solr document.
 */
@Getter
@Setter
@Service("extCriminalToSolrTransformer")
@RequiredArgsConstructor
public class ExtCriminalToSolrTransformer implements AcmObjectToSolrDocTransformer<ExtCriminal>
{
    @Autowired
    private ExtCriminalDao extCriminalDao;

    @Autowired
    private SearchAccessControlFields searchAccessControlFields;

    @Autowired
    private UserDao userJpaDao;

    /**
     * Fetches Criminal records changed on/after {@code lastModified}, one page
     * at a time, so the Solr reindexer can pick up updates without reloading
     * every Criminal in the system on every run.
     */
    @Override
    public List<ExtCriminal> getObjectsModifiedSince(Date lastModified, int start, int pageSize)
    {
        return getExtCriminalDao().findModifiedSince(lastModified, start, pageSize);
    }

    /**
     * Builds the core Solr document for a single Criminal: id, object type,
     * access-control fields, and the created/modified audit stamps. The
     * Criminal-specific fields (type, initiator, assignee, ...) are filled in
     * separately by {@link #mapAdditionalProperties(ExtCriminal, Map)}.
     */
    @Override
    public SolrAdvancedSearchDocument toSolrAdvancedSearch(ExtCriminal extCriminal)
    {
        SolrAdvancedSearchDocument solr = new SolrAdvancedSearchDocument();

        getSearchAccessControlFields().setAccessControlFields(solr, extCriminal);

        solr.setId(extCriminal.getId() + "-" + ExtCriminalConstants.OBJECT_TYPE);
        solr.setObject_id_s(extCriminal.getId() + "");
        solr.setObject_type_s(ExtCriminalConstants.OBJECT_TYPE);

        solr.setCreate_date_tdt(extCriminal.getCreated());
        solr.setCreator_lcs(extCriminal.getCreator());
        solr.setModified_date_tdt(extCriminal.getModified());
        solr.setModifier_lcs(extCriminal.getModifier());

        mapAdditionalProperties(extCriminal, solr.getAdditionalProperties());

        return solr;
    }

    /** Whether this transformer handles the given ACM object class - only {@link ExtCriminal}. */
    @Override
    public boolean isAcmObjectTypeSupported(Class acmObjectType)
    {
        return ExtCriminal.class.equals(acmObjectType);
    }

    /** The ACM object class this transformer handles. */
    @Override
    public Class<?> getAcmObjectTypeSupported()
    {
        return ExtCriminal.class;
    }

    /**
     * Fills in the Criminal-specific Solr fields that aren't part of the
     * generic ACM object shape: status, assignee (looked up from the
     * participants list), the criminal's title (for free-text search),
     * the participants list (as JSON, for the participants facet/column),
     * and the type/initiator values shown in the Criminal grid.
     * <p>
     * Creator/modifier full names are resolved here too so the UI can show
     * "Jane Doe" instead of a raw user id in the History and grid views.
     */
    @Override
    public void mapAdditionalProperties(ExtCriminal extCriminal, Map<String, Object> additionalProperties)
    {
        additionalProperties.put(STATUS_LCS, extCriminal.getStatus());
        String assigneeUserId = ParticipantUtils.getAssigneeIdFromParticipants(extCriminal.getParticipants());
        additionalProperties.put(ASSIGNEE_ID_LCS, assigneeUserId);
        AcmUser assignee = getUserJpaDao().quietFindByUserId(assigneeUserId);

        if (assignee != null)
        {
            additionalProperties.put(ASSIGNEE_FIRST_NAME_LCS, assignee.getFirstName());
            additionalProperties.put(ASSIGNEE_LAST_NAME_LCS, assignee.getLastName());
            additionalProperties.put(ASSIGNEE_FULL_NAME_LCS, assignee.getFirstName() + " " + assignee.getLastName());
        }

        additionalProperties.put(TITLE_PARSEABLE_LCS, extCriminal.getCriminalTitle());

        String participantsListJson = ParticipantUtils.createParticipantsListJson(extCriminal.getParticipants());
        additionalProperties.put("acm_participants_lcs", participantsListJson);

        additionalProperties.put("criminal_type_s", extCriminal.getCriminalType());
        additionalProperties.put("initiator_s", extCriminal.getInitiator());

        /** Additional properties for full names instead of ID's */
        AcmUser creator = getUserJpaDao().quietFindByUserId(extCriminal.getCreator());
        if (creator != null)
        {
            additionalProperties.put("creator_full_name_lcs", creator.getFirstName() + " " + creator.getLastName());
        }

        AcmUser modifier = getUserJpaDao().quietFindByUserId(extCriminal.getModifier());
        if (modifier != null)
        {
            additionalProperties.put("modifier_full_name_lcs", modifier.getFirstName() + " " + modifier.getLastName());
        }
    }
}

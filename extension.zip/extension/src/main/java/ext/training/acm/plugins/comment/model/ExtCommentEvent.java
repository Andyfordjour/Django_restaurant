package ext.training.acm.plugins.comment.model;

import com.armedia.acm.core.model.AcmEvent;

public class ExtCommentEvent extends AcmEvent
{
    public ExtCommentEvent(ExtComment extComment, String eventType, boolean succeeded, String ipAddress)
    {
        super(extComment);

        setObjectId(extComment.getId());
        setObjectType(extComment.getObjectType());
        setEventDate(extComment.getModified());
        setUserId(extComment.getModifier());
        setEventType(ExtCommentConstants.EVENT_BASE_TYPE + "." + eventType);
        setSucceeded(succeeded);
        setIpAddress(ipAddress);
    }
}
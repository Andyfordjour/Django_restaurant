package ext.training.acm.plugins.criminal.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.armedia.acm.data.AcmAbstractDao;
import com.google.common.base.Preconditions;

import ext.training.acm.plugins.criminal.model.ExtCriminal;
import ext.training.acm.plugins.criminal.model.ExtCriminalConstants;
import lombok.RequiredArgsConstructor;

/**
 * Database access object for {@link ExtCriminal}.
 * <p>
 * Extending {@link AcmAbstractDao} gives this class the usual CRUD/find
 * operations (save, find, findModifiedSince, etc.) for free - the only thing
 * added here is a proper delete, since the abstract base does not provide
 * one out of the box.
 */
@Service("extCriminalDao")
@RequiredArgsConstructor
public class ExtCriminalDao extends AcmAbstractDao<ExtCriminal>
{
    private static final Logger LOGGER = LoggerFactory.getLogger(ExtCriminalDao.class);

    /**
     * Deletes the Criminal with the given id.
     *
     * @param id
     *            id of the Criminal to delete; must not be {@code null}
     */
    @Transactional
    public void deleteById(Long id)
    {
        Preconditions.checkNotNull(id, "id cannot be null");
        getEm().remove(find(id));
    }

    /** Tells {@link AcmAbstractDao} which entity class this DAO manages. */
    @Override
    protected Class<ExtCriminal> getPersistenceClass()
    {
        return ExtCriminal.class;
    }

    /** The ACM object type this DAO handles - always "CRIMINAL". */
    @Override
    public String getSupportedObjectType()
    {
        return ExtCriminalConstants.OBJECT_TYPE;
    }
}

package ext.training.acm.plugins.comment.service;

import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.ASSIGNEE_FIRST_NAME_LCS;
import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.ASSIGNEE_FULL_NAME_LCS;
import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.ASSIGNEE_ID_LCS;
import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.ASSIGNEE_LAST_NAME_LCS;
import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.STATUS_LCS;
import static com.armedia.acm.services.search.model.solr.SolrAdditionalPropertiesConstants.TITLE_PARSEABLE_LCS;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.armedia.acm.services.dataaccess.service.SearchAccessControlFields;
import com.armedia.acm.services.participants.utils.ParticipantUtils;
import com.armedia.acm.services.search.model.solr.SolrAdvancedSearchDocument;
import com.armedia.acm.services.search.service.AcmObjectToSolrDocTransformer;
import com.armedia.acm.services.users.dao.UserDao;
import com.armedia.acm.services.users.model.AcmUser;

import ext.training.acm.plugins.comment.dao.ExtCommentDao;
import ext.training.acm.plugins.comment.model.ExtComment;
import ext.training.acm.plugins.comment.model.ExtCommentConstants;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Service("extCommentToSolrTransformer")
@RequiredArgsConstructor
public class ExtCommentToSolrTransformer implements AcmObjectToSolrDocTransformer<ExtComment>
{
    @Autowired
    private ExtCommentDao extCommentDao;

    @Autowired
    private SearchAccessControlFields searchAccessControlFields;

    @Autowired
    private UserDao userJpaDao;

    @Override
    public List<ExtComment> getObjectsModifiedSince(Date lastModified, int start, int pageSize)
    {
        return getExtCommentDao().findModifiedSince(lastModified, start, pageSize);
    }

    @Override
    public SolrAdvancedSearchDocument toSolrAdvancedSearch(ExtComment extComment)
    {
        SolrAdvancedSearchDocument solr = new SolrAdvancedSearchDocument();

        getSearchAccessControlFields().setAccessControlFields(solr, extComment);

        solr.setId(extComment.getId() + "-" + ExtCommentConstants.OBJECT_TYPE);
        solr.setObject_id_s(extComment.getId() + "");
        solr.setObject_type_s(ExtCommentConstants.OBJECT_TYPE);

        solr.setCreate_date_tdt(extComment.getCreated());
        solr.setCreator_lcs(extComment.getCreator());
        solr.setModified_date_tdt(extComment.getModified());
        solr.setModifier_lcs(extComment.getModifier());

        mapAdditionalProperties(extComment, solr.getAdditionalProperties());

        return solr;
    }

    @Override
    public boolean isAcmObjectTypeSupported(Class acmObjectType)
    {
        return ExtComment.class.equals(acmObjectType);
    }

    @Override
    public Class<?> getAcmObjectTypeSupported()
    {
        return ExtComment.class;
    }

    @Override
    public void mapAdditionalProperties(ExtComment extComment, Map<String, Object> additionalProperties)
    {
        additionalProperties.put(STATUS_LCS, extComment.getStatus());
        String assigneeUserId = ParticipantUtils.getAssigneeIdFromParticipants(extComment.getParticipants());
        additionalProperties.put(ASSIGNEE_ID_LCS, assigneeUserId);
        AcmUser assignee = getUserJpaDao().quietFindByUserId(assigneeUserId);

        if (assignee != null)
        {
            additionalProperties.put(ASSIGNEE_FIRST_NAME_LCS, assignee.getFirstName());
            additionalProperties.put(ASSIGNEE_LAST_NAME_LCS, assignee.getLastName());
            additionalProperties.put(ASSIGNEE_FULL_NAME_LCS, assignee.getFirstName() + " " + assignee.getLastName());
        }

        additionalProperties.put(TITLE_PARSEABLE_LCS,
                "Complaint ID " + extComment.getParentId() + " (ExtComment Date " + extComment.getCreated() + ")");

        String participantsListJson = ParticipantUtils.createParticipantsListJson(extComment.getParticipants());
        additionalProperties.put("acm_participants_lcs", participantsListJson);

        additionalProperties.put("comment_detail_s", extComment.getDetails());
        additionalProperties.put("parent_id_i", extComment.getParentId());
        additionalProperties.put("parent_type_s", extComment.getParentType());
        additionalProperties.put("parent_title_s", extComment.getParentTitle());

        /** Additional properties for full names instead of ID's */
        AcmUser creator = getUserJpaDao().quietFindByUserId(extComment.getCreator());
        if (creator != null)
        {
            additionalProperties.put("creator_full_name_lcs", creator.getFirstName() + " " + creator.getLastName());
        }

        AcmUser modifier = getUserJpaDao().quietFindByUserId(extComment.getModifier());
        if (modifier != null)
        {
            additionalProperties.put("modifier_full_name_lcs", modifier.getFirstName() + " " + modifier.getLastName());
        }
    }
}

package ext.training.acm.plugins.criminal.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.armedia.acm.core.AcmObject;
import com.armedia.acm.data.AcmEntity;
import com.armedia.acm.data.converter.BooleanToStringConverter;
import com.armedia.acm.services.participants.model.AcmAssignedObject;
import com.armedia.acm.services.participants.model.AcmParticipant;

import lombok.Getter;
import lombok.Setter;

/**
 * JPA entity for a Criminal record, backed by the {@code ext_criminal} table.
 * <p>
 * This is the simplest of the three modules in this extension (compare to
 * Complaint/Comment) - it only has a title, a type, an initiator (the person
 * who reported it) and a status, plus the usual ACM bookkeeping fields
 * (creator, created date, modifier, modified date, participants).
 * <p>
 * Implementing {@link AcmObject}, {@link AcmEntity} and {@link AcmAssignedObject}
 * is what lets the rest of the ACM framework (search indexing, participants,
 * audit events, the generic object browser) treat a Criminal like any other
 * ACM object without needing Criminal-specific code everywhere.
 */
@Entity
@Table(name = "ext_criminal")
@Getter
@Setter
public class ExtCriminal implements Serializable, AcmObject, AcmEntity, AcmAssignedObject
{
    /**
     * Primary key. Generated from the {@code ext_criminal_id} table-based
     * sequence (starts at 100, increments by 1) rather than a native DB
     * identity column, for portability across database vendors.
     */
    @Id
    @TableGenerator(name = "ext_criminal_gen", table = "ext_criminal_id", pkColumnName = "ext_criminal_seq_name", valueColumnName = "ext_criminal_seq_num", pkColumnValue = "ext_criminal", initialValue = 100, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "ext_criminal_gen")
    @Column(name = "ext_criminal_id")
    private Long id;

    /** The criminal's title/name, as entered on the New Criminal form. Required. */
    @Column(name = "ext_criminal_title")
    private String criminalTitle;

    /**
     * The category of criminal (e.g. Fraud, Arson, Robbery). Stores the "key"
     * of an entry from the shared complaint-types lookup - see the Angular
     * side's {@code ObjectLookupService.getComplaintTypes()} for where the
     * actual list of values comes from.
     */
    @Column(name = "ext_criminal_type")
    private String criminalType;

    /**
     * Full name of the person who initiated/reported this criminal record.
     * Deliberately a plain String, not a Person association - the UI lets the
     * user pick or create a Person via a picker popup, but only the resulting
     * display name is persisted here.
     */
    @Column(name = "ext_criminal_initiator")
    private String initiator;

    /** Always {@link ExtCriminalConstants#OBJECT_TYPE} ("CRIMINAL"). */
    @Column(name = "ext_criminal_object_type")
    private String objectType = ExtCriminalConstants.OBJECT_TYPE;

    /**
     * Current status of the record. Defaults to "ACTIVE" on creation (see
     * {@link #beforeInsert()}) - there is no admin-configurable status lookup
     * for Criminal, so this is effectively just a free-form marker.
     */
    @Column(name = "ext_criminal_status")
    private String status;

    /**
     * Participants (assignee, owning group, etc.) attached to this Criminal.
     * The {@code @JoinColumns} tie each {@link AcmParticipant} row back to
     * this Criminal's id + object type, since participants are a generic,
     * shared table used by every ACM object type, not just Criminal.
     */
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumns({
            @JoinColumn(name = "cm_object_id", referencedColumnName = "ext_criminal_id"),
            @JoinColumn(name = "cm_object_type", referencedColumnName = "ext_criminal_object_type")
    })
    private List<AcmParticipant> participants = new ArrayList<>();

    /** Whether this record is restricted (limited visibility). Defaults to unrestricted. */
    @Column(name = "ext_criminal_restricted_flag")
    @Convert(converter = BooleanToStringConverter.class)
    private Boolean restricted = false;

    /** User ID of whoever created this record. Set once, never updated afterwards. */
    @Column(name = "ext_criminal_creator", updatable = false)
    private String creator;

    /** Timestamp of when this record was first created. Set once, never updated afterwards. */
    @Column(name = "ext_criminal_created", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

    /** User ID of whoever last saved/edited this record. */
    @Column(name = "ext_criminal_modifier")
    private String modifier;

    /** Timestamp of the most recent save/edit. */
    @Column(name = "ext_criminal_modified")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modified;

    /**
     * JPA lifecycle callback run right before the very first INSERT.
     * Defaults the status to "ACTIVE" if it wasn't set, and makes sure every
     * participant row points back at this Criminal (see {@link #setupChildPointers()}).
     */
    @PrePersist
    protected void beforeInsert()
    {
        if (getStatus() == null || getStatus().trim().isEmpty())
        {
            setStatus("ACTIVE");
        }

        setupChildPointers();
    }

    /**
     * JPA lifecycle callback run right before every UPDATE.
     * Re-syncs participant pointers in case participants were added/replaced
     * since this entity was loaded (see {@link #setupChildPointers()}).
     */
    @PreUpdate
    protected void beforeUpdate()
    {
        setupChildPointers();
    }

    /**
     * Makes sure every participant in {@link #participants} has its
     * objectId/objectType pointing back at this Criminal. Needed because
     * new participants are often built with just a role and a user, without
     * knowing this Criminal's generated id yet.
     */
    private void setupChildPointers()
    {
        for (AcmParticipant ap : getParticipants())
        {
            ap.setObjectId(getId());
            ap.setObjectType(getObjectType());
        }
    }

    @Override
    public String getObjectType()
    {
        return objectType;
    }

    @Override
    public Long getId()
    {
        return id;
    }

    @Override
    public String getCreator()
    {
        return creator;
    }

    @Override
    public void setCreator(String creator)
    {
        this.creator = creator;
    }

    @Override
    public String getModifier()
    {
        return modifier;
    }

    @Override
    public void setModifier(String modifier)
    {
        this.modifier = modifier;
    }

    @Override
    public Date getCreated()
    {
        return created;
    }

    @Override
    public void setCreated(Date created)
    {
        this.created = created;
    }

    @Override
    public Date getModified()
    {
        return modified;
    }

    @Override
    public void setModified(Date modified)
    {
        this.modified = modified;
    }

    @Override
    public List<AcmParticipant> getParticipants()
    {
        return participants;
    }

    @Override
    public void setParticipants(List<AcmParticipant> participants)
    {
        this.participants = participants;
    }

    @Override
    public Boolean getRestricted()
    {
        return restricted;
    }

    @Override
    public String getStatus()
    {
        return status;
    }
}

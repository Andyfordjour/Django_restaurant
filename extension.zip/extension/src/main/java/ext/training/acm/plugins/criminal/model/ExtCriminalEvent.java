package ext.training.acm.plugins.criminal.model;

import com.armedia.acm.core.model.AcmEvent;

/**
 * Audit/history event published whenever a Criminal is created, updated or
 * deleted (see {@code ExtCriminalAPIController#publishExtCriminalEvent}).
 * <p>
 * ACM's generic audit/history infrastructure listens for {@link AcmEvent}
 * subclasses like this one and records them, which is what powers the
 * "History" tab shown in the Criminal module's UI.
 */
public class ExtCriminalEvent extends AcmEvent
{
    /**
     * Builds the event, copying the relevant identifying/audit fields off the
     * given Criminal so the event carries enough information to be recorded
     * even after the Criminal itself has changed further or been deleted.
     *
     * @param extCriminal
     *            the Criminal this event is about
     * @param eventType
     *            one of {@link ExtCriminalConstants}'s EVENT_TYPE_* suffixes
     *            (e.g. "create", "update", "delete")
     * @param succeeded
     *            whether the underlying operation succeeded
     * @param ipAddress
     *            IP address of the user who triggered the operation
     */
    public ExtCriminalEvent(ExtCriminal extCriminal, String eventType, boolean succeeded, String ipAddress)
    {
        super(extCriminal);

        setObjectId(extCriminal.getId());
        setObjectType(extCriminal.getObjectType());
        setEventDate(extCriminal.getModified());
        setUserId(extCriminal.getModifier());
        setEventType(ExtCriminalConstants.EVENT_BASE_TYPE + "." + eventType);
        setSucceeded(succeeded);
        setIpAddress(ipAddress);
    }
}

package ext.training.acm.plugins.comment.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.armedia.acm.core.AcmObject;
import com.armedia.acm.data.AcmEntity;
import com.armedia.acm.data.converter.BooleanToStringConverter;
import com.armedia.acm.services.participants.model.AcmAssignedObject;
import com.armedia.acm.services.participants.model.AcmParticipant;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "ext_comment")
@Getter
@Setter
public class ExtComment implements Serializable, AcmObject, AcmEntity, AcmAssignedObject
{
    @Id
    @TableGenerator(name = "ext_comment_gen", table = "ext_comment_id", pkColumnName = "ext_comment_seq_name", valueColumnName = "ext_comment_seq_num", pkColumnValue = "ext_comment", initialValue = 100, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "ext_comment_gen")
    @Column(name = "ext_comment_id")
    private Long id;

    @Column(name = "ext_comment_details")
    private String details;

    @Column(name = "ext_comment_object_type")
    private String objectType = ExtCommentConstants.OBJECT_TYPE;

    @Column(name = "ext_comment_parent_id")
    private Long parentId;

    @Column(name = "ext_comment_parent_type")
    private String parentType;

    @Column(name = "ext_comment_parent_title")
    private String parentTitle;

    @Column(name = "ext_comment_status")
    private String status;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumns({
            @JoinColumn(name = "cm_object_id", referencedColumnName = "ext_comment_id"),
            @JoinColumn(name = "cm_object_type", referencedColumnName = "ext_comment_object_type")
    })
    private List<AcmParticipant> participants = new ArrayList<>();

    @Column(name = "ext_comment_restricted_flag")
    @Convert(converter = BooleanToStringConverter.class)
    private Boolean restricted = false;

    @Column(name = "ext_comment_creator", updatable = false)
    private String creator;

    @Column(name = "ext_comment_created", updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;

    @Column(name = "ext_comment_modifier")
    private String modifier;

    @Column(name = "ext_comment_modified")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modified;

    @PrePersist
    protected void beforeInsert()
    {
        if (getStatus() == null || getStatus().trim().isEmpty())
        {
            setStatus("ACTIVE");
        }

        setupChildPointers();
    }

    @PreUpdate
    protected void beforeUpdate()
    {
        setupChildPointers();
    }

    private void setupChildPointers()
    {
        for (AcmParticipant ap : getParticipants())
        {
            ap.setObjectId(getId());
            ap.setObjectType(getObjectType());
        }
    }

    @Override
    public String getObjectType()
    {
        return objectType;
    }

    @Override
    public Long getId()
    {
        return id;
    }

    @Override
    public String getCreator()
    {
        return creator;
    }

    @Override
    public void setCreator(String creator)
    {
        this.creator = creator;
    }

    @Override
    public String getModifier()
    {
        return modifier;
    }

    @Override
    public void setModifier(String modifier)
    {
        this.modifier = modifier;
    }

    @Override
    public Date getCreated()
    {
        return created;
    }

    @Override
    public void setCreated(Date created)
    {
        this.created = created;
    }

    @Override
    public Date getModified()
    {
        return modified;
    }

    @Override
    public void setModified(Date modified)
    {
        this.modified = modified;
    }

    @Override
    public List<AcmParticipant> getParticipants()
    {
        return participants;
    }

    @Override
    public void setParticipants(List<AcmParticipant> participants)
    {
        this.participants = participants;
    }

    @Override
    public Boolean getRestricted()
    {
        return restricted;
    }

    @Override
    public String getStatus()
    {
        return status;
    }
}

package ext.training.acm.plugins.comment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ext.training.acm.plugins.comment.dao.ExtCommentDao;
import ext.training.acm.plugins.comment.model.ExtComment;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Service("extCommentService")
@RequiredArgsConstructor
public class ExtCommentServiceImpl implements ExtCommentService
{
    @Autowired
    private ExtCommentDao extCommentDao;

    @Override
    public ExtComment save(ExtComment comment)
    {
        return getExtCommentDao().save(comment);
    }

    @Override
    public ExtComment findById(Long id)
    {
        return getExtCommentDao().find(id);
    }

    @Override
    public void deleteById(Long id)
    {
        getExtCommentDao().deleteById(id);
    }
}

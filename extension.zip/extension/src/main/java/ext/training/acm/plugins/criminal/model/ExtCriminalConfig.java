package ext.training.acm.plugins.criminal.model;

import org.springframework.beans.factory.annotation.Value;

import com.armedia.acm.pluginmanager.service.AcmPluginConfigBean;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Exposes the Criminal module's search-tree defaults (filter, sort, query)
 * so the ACM plugin framework can advertise them to the UI/config API.
 * <p>
 * Values are injected from properties named
 * {@code criminal.plugin.search.tree.filter}, {@code .sort} and
 * {@code .searchQuery} (defined in the module's Spring configuration), the
 * same mechanism every other ACM plugin (Complaint, Case File, ...) uses for
 * its own tree defaults.
 */
public class ExtCriminalConfig implements AcmPluginConfigBean
{
    /** Default Solr filter query applied to the Criminal tree/list (e.g. hide deleted). */
    @JsonProperty("criminal.plugin.search.tree.filter")
    @Value("${criminal.plugin.search.tree.filter}")
    private String searchTreeFilter;

    /** Default sort order applied to the Criminal tree/list. */
    @Value("${criminal.plugin.search.tree.sort}")
    private String searchTreeSort;

    /** Default search query applied to the Criminal tree/list. */
    @JsonProperty("criminal.plugin.search.tree.searchQuery")
    @Value("${criminal.plugin.search.tree.searchQuery}")
    private String searchTreeSearchQuery;

    @Override
    public String getSearchTreeFilter()
    {
        return searchTreeFilter;
    }

    @Override
    public String getSearchTreeSort()
    {
        return searchTreeSort;
    }

    @Override
    public String getSearchTreeQuery()
    {
        return searchTreeSearchQuery;
    }
}

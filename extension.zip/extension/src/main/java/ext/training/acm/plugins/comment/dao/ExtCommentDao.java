package ext.training.acm.plugins.comment.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.armedia.acm.data.AcmAbstractDao;
import com.google.common.base.Preconditions;

import ext.training.acm.plugins.comment.model.ExtComment;
import ext.training.acm.plugins.comment.model.ExtCommentConstants;
import lombok.RequiredArgsConstructor;

@Service("extCommentDao")
@RequiredArgsConstructor
public class ExtCommentDao extends AcmAbstractDao<ExtComment>
{
    private static final Logger LOGGER = LoggerFactory.getLogger(ExtCommentDao.class);

    @Transactional
    public void deleteById(Long id)
    {
        Preconditions.checkNotNull(id, "id cannot be null");
        getEm().remove(find(id));
    }

    @Override
    protected Class<ExtComment> getPersistenceClass()
    {
        return ExtComment.class;
    }

    @Override
    public String getSupportedObjectType()
    {
        return ExtCommentConstants.OBJECT_TYPE;
    }
}

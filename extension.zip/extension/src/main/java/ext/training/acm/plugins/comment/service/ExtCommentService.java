package ext.training.acm.plugins.comment.service;

import ext.training.acm.plugins.comment.model.ExtComment;

public interface ExtCommentService
{
    ExtComment save(ExtComment comment);

    ExtComment findById(Long id);

    void deleteById(Long id);
}

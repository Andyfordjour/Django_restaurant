package ext.training.acm.plugins.criminal.model;

/**
 * Shared constant values for the Criminal plugin.
 * <p>
 * Centralizing these here means the object type name and audit event
 * type suffixes only have to be spelled correctly in one place, and every
 * other Criminal class (DAO, service, controller, Solr transformer, event)
 * refers back to these constants instead of repeating string literals.
 */
public interface ExtCriminalConstants
{
    /**
     * The ACM object type for a Criminal record. Used everywhere a Criminal
     * needs to be identified among other object types (e.g. Complaint,
     * Case File) - in the database column {@code ext_criminal_object_type},
     * in Solr documents, and in the Angular UI's search/tree queries.
     */
    String OBJECT_TYPE = "CRIMINAL";

    /**
     * The base namespace for Criminal audit/history events. The actual event
     * type published is this value plus "." plus one of the EVENT_TYPE_*
     * constants below, e.g. {@code ext.training.acm.plugins.criminal.event.create}.
     */
    String EVENT_BASE_TYPE = "ext.training.acm.plugins.criminal.event";

    /** Event type suffix used when a new Criminal is created. */
    String EVENT_TYPE_CREATE = "create";

    /** Event type suffix used when an existing Criminal is edited/saved. */
    String EVENT_TYPE_UPDATE = "update";

    /** Event type suffix used when a Criminal is deleted. */
    String EVENT_TYPE_DELETE = "delete";
}

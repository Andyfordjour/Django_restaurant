package ext.training.acm.plugins.comment.web.api;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ext.training.acm.plugins.comment.model.ExtComment;
import ext.training.acm.plugins.comment.model.ExtCommentConstants;
import ext.training.acm.plugins.comment.model.ExtCommentEvent;
import ext.training.acm.plugins.comment.service.ExtCommentService;
import lombok.Getter;
import lombok.Setter;

@RestController
@RequestMapping({ "/api/v1/plugin/ext/comment" })
@Getter
@Setter
public class ExtCommentAPIController implements ApplicationEventPublisherAware
{
    @Autowired
    private ExtCommentService extCommentService;

    private ApplicationEventPublisher applicationEventPublisher;

    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ExtComment saveExtComment(@RequestBody ExtComment extComment, HttpSession httpSession)
    {
        String eventType = extComment.getId() == null ? ExtCommentConstants.EVENT_TYPE_CREATE : ExtCommentConstants.EVENT_TYPE_UPDATE;
        String ipAddress = (String) httpSession.getAttribute("acm_ip_address");

        extComment = getExtCommentService().save(extComment);

        publishExtCommentEvent(extComment, eventType, ipAddress);

        return extComment;
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ExtComment findById(@PathVariable("id") Long id)
    {
        return getExtCommentService().findById(id);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public void deleteExtCommentById(@PathVariable("id") Long id, HttpSession httpSession)
    {
        ExtComment extComment = getExtCommentService().findById(id);

        String eventType = ExtCommentConstants.EVENT_TYPE_DELETE;
        String ipAddress = (String) httpSession.getAttribute("acm_ip_address");

        getExtCommentService().deleteById(id);

        publishExtCommentEvent(extComment, eventType, ipAddress);
    }

    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher)
    {
        this.applicationEventPublisher = applicationEventPublisher;
    }

    private void publishExtCommentEvent(ExtComment extComment, String eventType, String ipAddress)
    {
        ExtCommentEvent event = new ExtCommentEvent(extComment, eventType, true, ipAddress);
        getApplicationEventPublisher().publishEvent(event);
    }
}

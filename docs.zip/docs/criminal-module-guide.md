# Criminal Module — Architecture & Build Guide

*A reference for understanding how the Criminal module is put together, and
a step-by-step recipe for building another module the same way inside
`complaint-extension`.*

---

## 1. Where this module lives

`complaint-extension` is a Maven multi-module project with four modules:

| Maven module | What it holds |
|---|---|
| `extension` | The backend Java code (JPA entities, DAOs, services, REST controllers, Solr transformers, Spring XML wiring, Liquibase DB schema) |
| `extension-ui` | The Angular frontend (controllers, services, views, routes, module config) |
| `config` | Configuration overlays merged into ArkCase's config server at deploy time (text labels, navigator/menu entries, object-type registrations) |
| `war` | Packages the above into the deployable web application |

The Criminal module has files in all four. Every ACM module (Complaint,
Case, Comment, Criminal, ...) follows this same four-part split — that's
the pattern to repeat for a new module.

---

## 2. The big picture: how a request flows

```
 Angular VIEW (.html)
     |  ng-click / ng-model
     v
 Angular CONTROLLER (.controller.js)
     |  calls
     v
 Angular SERVICE ($resource)  ---HTTP--->  Spring REST CONTROLLER (web/api)
                                                 |  calls
                                                 v
                                           SERVICE interface + impl
                                                 |  calls
                                                 v
                                           DAO  --(JPA)-->  DATABASE (ext_criminal table)
```

Separately, whenever a Criminal is saved, ACM's reindex job asks the
**Solr transformer** to turn the entity into a search document, which is
what makes it show up in the left-hand tree, the global search box, and
facet filters. That path looks like:

```
 ExtCriminal (entity) -> ExtCriminalToSolrTransformer -> Solr document -> searchable
```

Everything below is organized by *where the file lives* and *what job it
does* in that picture.

---

## 3. Backend — `extension` module (`ext.training.acm.plugins.criminal`)

| File | Role |
|---|---|
| `model/ExtCriminal.java` | The JPA **entity** — one Java class per row in the `ext_criminal` database table. Holds the actual data: title, type, initiator, status, plus the standard ACM bookkeeping fields (creator, created date, modifier, modified date, participants, restricted flag). Implements ACM's `AcmObject`/`AcmEntity`/`AcmAssignedObject` interfaces so the rest of the framework (search, participants, audit) can treat it like any other object type without special-casing it. |
| `model/ExtCriminalConstants.java` | Shared string constants: the object type name (`"CRIMINAL"`) and the audit event type suffixes (create/update/delete). Everything else in the module imports these instead of repeating string literals. |
| `model/ExtCriminalConfig.java` | A small Spring-managed bean exposing this module's default search-tree filter/sort/query (read from Spring properties). Used by the plugin manager to advertise defaults to the UI. |
| `model/ExtCriminalEvent.java` | An `AcmEvent` subclass published every time a Criminal is created, updated, or deleted. ACM's generic audit/history system listens for these — this is what makes entries show up in the module's "History" tab. |
| `dao/ExtCriminalDao.java` | Data-access object. Extends ACM's `AcmAbstractDao`, which already provides `save`, `find`, `findModifiedSince`, etc. This class only adds a proper `deleteById`. |
| `service/ExtCriminalService.java` | The **business-layer interface**: `save`, `findById`, `deleteById`. Kept separate from the DAO so the REST controller depends on behavior, not persistence details. |
| `service/ExtCriminalServiceImpl.java` | The interface's implementation — currently a thin pass-through to the DAO. This is the layer where you'd add business rules later (validation, notifications, etc.) without touching the controller. |
| `service/ExtCriminalToSolrTransformer.java` | Converts an `ExtCriminal` into the Solr document ACM indexes it as. Fills in both the generic fields (id, object type, access control, created/modified) and Criminal-specific ones (type, initiator, assignee full name, etc.) that power the tree, search box, and grid columns. |
| `web/api/ExtCriminalAPIController.java` | The **REST controller**, mounted at `/api/v1/plugin/ext/criminal`. Three endpoints: `POST` (create/update), `GET /{id}` (fetch one), `DELETE /{id}`. Publishes an `ExtCriminalEvent` after every write. This is exactly what the Angular `Criminals.InfoService` calls. |
| `resources/ddl/tables/ext-criminal-db-tables-1.0.xml` | **Liquibase changeset** defining the actual `ext_criminal` table (columns, types, constraints) and its id-generator table `ext_criminal_id`. This runs once at deploy time to create/update the schema — it's the source of truth for what columns exist. |
| `resources/spring/spring-library-ext-criminal.xml` | Spring XML that component-scans the `criminal` package, and registers the `AcmPlugin` bean (`criminalPlugin`) that tells ACM's plugin manager "there is a module called Criminal, its object type is CRIMINAL, here's its config bean." |
| `resources/spring/spring-web-ext-criminal.xml` | Spring XML that component-scans the `criminal` package for the **web layer** specifically (so `@RestController` beans get picked up in the web application context). |

---

## 4. Frontend — `extension-ui` module (`modules/criminals`)

| File | Role |
|---|---|
| `criminals.client.module.js` | Registers the Angular module named `criminals` with `ApplicationConfiguration.registerModule(...)`. Every other file in this list does `angular.module('criminals')...` — this is the one line that creates that module in the first place. |
| `config/criminals.client.config.js` | An Angular `.run()` block that reads the module's menu config and registers the left-nav / topbar menu items via the shared `Menus` service. |
| `config/criminals.client.routes.js` | Defines the Angular UI-Router **states** (URLs) for the module: `criminals` (main page), `new-criminal`, `criminals.main/.details/.history/.participants`. Each state points at a `templateUrl` — this is what makes clicking a tab actually swap the visible template. |
| `module_config/config.json` | The module's **declarative configuration**: menu entries, left-nav tree filters/sorters/node types, and the list of "components" (`info`, `details`, `participants`, `history`) with their titles, icons, and — for grid-based components — column definitions and picker-dialog settings. Read at runtime via `ConfigService`; this is what several controllers call `ConfigService.getModuleConfig("criminals")` or `getComponentConfig(...)` to fetch. |
| `controllers/criminals.client.controller.js` | The top-level `CriminalsController`. Uses `Helper.ObjectBrowserService.Content` to load whichever Criminal is selected and manage the tab links shown at the bottom of the page. |
| `controllers/criminals-list.client.controller.js` | `CriminalsListController` — drives the left-hand tree widget. Uses `Helper.ObjectBrowserService.Tree` plus `Criminals.ListService` to load/reset/page through the list of criminals. |
| `controllers/components/criminals-info.client.controller.js` | Logic for the **header bar** shown above the tabs (title, status, type, initiator, created date) — the click-to-edit fields and the "Add Person" popup for Initiator. |
| `controllers/components/criminals-details.client.controller.js` | Logic for the **Details tab** — same fields as the header, edited via plain inputs plus an explicit Save button instead of click-to-edit. |
| `controllers/components/criminals-participants.client.controller.js` | Very thin — just builds a config object (`participantsInit`) and hands it to the shared `core-participants` directive, which does all the actual participant-management UI/logic. |
| `controllers/components/dialogs/new-criminal-modal.client.controller.js` | Logic for the **"New Criminal" popup**: the form model, the Criminal Type dropdown, the Initiator "Add Person" popup, and Save/Dismiss. |
| `services/criminals-info.client.service.js` | `Criminals.InfoService` — the `$resource`-based service that actually calls the backend (`GET/POST/DELETE /api/v1/plugin/ext/criminal`). Every controller that reads or writes a single Criminal goes through this. |
| `services/criminals-list.client.service.js` | `Criminals.ListService` — queries the generic ACM search API (`ObjectListService._queryObjects`) filtered to object type CRIMINAL, with a small FIFO cache so paging the tree doesn't re-query unnecessarily. |
| `views/criminals.client.view.html` | The top-level page layout: left sidebar (tree) + right content area (header bar, active tab via `data-ui-view`, tab links footer). |
| `views/criminals-list.client.view.html` | Thin wrapper around the shared `<object-tree>` directive, bound to `CriminalsListController`'s scope variables. |
| `views/components/criminals-info.client.view.html` | The header bar markup (see Section 6 below for how its row layout matches other modules). |
| `views/components/criminals-details.client.view.html` | The Details tab markup — title/type/initiator inputs plus a Save button. |
| `views/components/criminals-participants.client.view.html` | Just `<core-participants participants-init="participantsInit"/>` — one line, delegates entirely to the shared directive. |
| `views/components/dialogs/new-criminal-modal.client.view.html` | The "New Criminal" popup markup: title input, type dropdown, initiator (click-to-open-popup) input, Save/Cancel buttons. |

---

## 5. Config — `config` module

| File | Role |
|---|---|
| `acm-config-server-repo/labels/criminals-en.yaml` | All of the module's English text labels (`criminals.title`, `criminals.comp.new.*`, `criminals.comp.info.*`, etc.) — anywhere a view has `translate` or `{{ '...' \| translate }}`, the key resolves here. |
| `acm/app-config.xml` | Spring XML registering: (1) `criminalNavigatorAction` / `createCriminalAction` beans — the left-nav entry and topbar "Criminal" button, both gated by the `ext-criminal-module` privilege; (2) the `criminalType` `AcmObjectType` bean — tells the app what URL pattern to use when linking to a Criminal (`/home.html#!/criminals/%d/main`). |
| `acm-config-server-repo/arkcase-custom.yaml` | Has a `~navigator.criminals` entry (name, icon, required privilege) that's an alternate/overlay way of registering the same left-nav item through the YAML-based config server rather than Spring XML. |

---

## 6. A worked example: why the header bar has 3 rows

This is a good illustration of "match the existing pattern" in practice.
Complaint's and Case's header bars (`complaint-info.client.view.html`,
`case-info.client.view.html`) both use **three** content rows:

1. Title + Status (and, for those modules, the object number on the right)
2. Type / Created / Priority / Office Location (up to 4 columns)
3. Assignee / Owning Group / Due Date (up to 3 columns)

Criminal doesn't have Priority, Assignee, Owning Group, Office Location or
Due Date on its backend entity at all — only Title, Status, Type,
Initiator, and Created. So `criminals-info.client.view.html` mirrors the
*same three-row skeleton*, just with fewer columns filled in per row:

1. Title + Status
2. Type / Created (2 of 4 columns used)
3. Initiator (1 of 3 columns used)

Result: the header is visually the same height as every other module's,
without inventing data fields that don't exist. That's the general rule
to follow for a new module too — reuse the shared layout skeleton, and
leave a column empty rather than stretching or shrinking the grid.

---

## 7. Step-by-step: building a new module the same way

Say you wanted to add a "Victim" module. Here's the order to build it in,
using Criminal's files as the template for each step.

### Phase A — Decide the data shape
Write down the fields (title? a type/category? a status? who's linked to
it?) and which are required. Criminal kept this deliberately small:
title, type, initiator, status.

### Phase B — Backend (`extension` module)
1. **DB table**: copy `ext-criminal-db-tables-1.0.xml` → new Liquibase
   changeset for your table + its id-sequence table.
2. **Entity**: copy `ExtCriminal.java` → rename, adjust `@Column`s to your
   fields, keep the `AcmObject`/`AcmEntity`/`AcmAssignedObject` boilerplate.
3. **Constants**: copy `ExtCriminalConstants.java` → new `OBJECT_TYPE` and
   event-type constants.
4. **DAO**: copy `ExtCriminalDao.java` → point `getPersistenceClass()` and
   `getSupportedObjectType()` at your new entity/constant.
5. **Service interface + impl**: copy `ExtCriminalService(Impl).java`.
6. **REST controller**: copy `ExtCriminalAPIController.java` → change the
   `@RequestMapping` path and the imports.
7. **Solr transformer**: copy `ExtCriminalToSolrTransformer.java` → map
   your own fields into `additionalProperties`.
8. **Event class**: copy `ExtCriminalEvent.java`.
9. **Config bean** (optional, only if you want configurable tree
   defaults): copy `ExtCriminalConfig.java`.
10. **Spring wiring**: copy both `spring-library-ext-criminal.xml` and
    `spring-web-ext-criminal.xml`, updating the `base-package` and the
    `AcmPlugin` bean's `suportedObjectTypesNames`.

### Phase C — Frontend (`extension-ui` module)
1. **Module file**: copy `criminals.client.module.js`, rename the module.
2. **Config + routes**: copy `criminals.client.config.js` and
   `criminals.client.routes.js`, update the module id and state names.
3. **`module_config/config.json`**: copy and edit — menus, tree
   filters/sorters, and one `components` entry per tab you want
   (`info`, `details`, `participants`, `history`, ...).
4. **Services**: copy `criminals-info.client.service.js` (single-object
   CRUD) and `criminals-list.client.service.js` (tree/list queries).
5. **Controllers**: copy the matching controller for each tab you're
   building — main content controller, list/tree controller, info
   (header) controller, details controller, participants controller,
   new-object modal controller.
6. **Views**: copy the matching `.html` for every controller above.
7. **Reuse, don't rebuild, shared pieces**: the "Add Person" popup
   (`modules/common/views/add-person-modal.client.view.html` +
   `Common.AddPersonModalController`), the participants directive
   (`core-participants`), and the object-tree directive
   (`<object-tree>`) are all shared across every module — call them the
   same way Criminal does instead of writing new versions.

### Phase D — Config module
1. Add a `<yourmodule>-en.yaml` labels file (copy `criminals-en.yaml`).
2. Add navigator/topbar entries in `app-config.xml` (copy the
   `criminalNavigatorAction`/`createCriminalAction`/`criminalType` beans)
   and/or the YAML `~navigator` entry in `arkcase-custom.yaml`.
3. Decide on a privilege name (Criminal used `ext-criminal-module`) and
   use it consistently across the navigator/topbar beans.

### Phase E — Build, deploy, test
1. Rebuild the `extension`, `extension-ui`, and `config` Maven modules
   (and `war` if you're producing a fresh deployable).
2. Redeploy to your app server.
3. Log in, confirm the new left-nav/topbar entry appears, create a test
   record, and check the header bar, Details tab, and History tab all
   show it correctly.

---

## 8. Where the actual code comments live

Every file above has explanatory comments written directly in it:
- Java files: look for `/** ... */` Javadoc blocks above each class,
  field, and method.
- Angular controllers: same `/** @ngdoc ... */` style blocks.
- Angular views (`.html`): look for `<!-- ... -->` blocks.

Those comments explain the *local* "what does this specific line do and
why" detail; this document is the *big picture* — read this first to get
oriented, then dive into a specific file's comments for the details.

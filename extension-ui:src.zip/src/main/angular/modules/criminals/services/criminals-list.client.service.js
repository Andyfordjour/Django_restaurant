'use strict';

angular.module('services').factory('Criminals.ListService', ['$resource', '$translate', 'Acm.StoreService', 'UtilService', 'ObjectService', 'Object.ListService', function ($resource, $translate, Store, Util, ObjectService, ObjectListService) {
    var Service = $resource('api/latest/plugin', {}, {});

    Service.SessionCacheNames = {};
    Service.CacheNames = {
        CRIMINAL_LIST: "CriminalList"
    };

    Service.resetCriminalsTreeData = function () {
        var cacheCriminalList = new Store.CacheFifo(Service.CacheNames.CRIMINAL_LIST);
        cacheCriminalList.reset();
    };

    Service.updateCriminalsTreeData = function (start, n, sort, filters, query, nodeData) {
        ObjectListService.updateObjectTreeData(Service.CacheNames.CRIMINAL_LIST, start, n, sort, filters, query, nodeData);
    };

    Service.queryCriminalsTreeData = function (start, n, sort, filters, query, nodeMaker) {
        var param = {};
        param.objectType = $translate.instant("criminals.objectType");
        param.start = Util.goodValue(start, 0);
        param.n = Util.goodValue(n, 32);
        /*param.sort = Util.goodValue(sort);
        param.filters = Util.goodValue(filters);*/
        param.query = Util.goodValue(query);

        var cacheCriminalList = new Store.CacheFifo(Service.CacheNames.CRIMINAL_LIST);
        var cacheKey = param.start + "." + param.n + "." + param.sort + "." + param.filters + "." + param.query;
        var treeData = cacheCriminalList.get(cacheKey);

        return Util.serviceCall({
            service: ObjectListService._queryObjects,
            param: param,
            result: treeData,
            onSuccess: function (data) {
                treeData = {
                    docs: [],
                    total: data.response.numFound
                };
                var docs = data.response.docs;
                _.forEach(docs, function (doc) {
                    var node;
                    if (nodeMaker) {
                        node = nodeMaker(doc);
                    } else {
                        node = {
                            nodeId: Util.goodValue(doc.object_id_s, 0),
                            nodeType: $translate.instant("criminals.objectType"),
                            nodeTitle: Util.goodValue(doc.title_parseable_lcs),
                            nodeToolTip: Util.goodValue(doc.title_parseable_lcs)
                        };
                    }
                    treeData.docs.push(node);
                });
                cacheCriminalList.put(cacheKey, treeData);
                return treeData;
            }
        });
    };

    return Service;
}]);

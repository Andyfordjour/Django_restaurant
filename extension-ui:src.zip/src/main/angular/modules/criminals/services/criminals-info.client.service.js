'use strict';

angular.module('services').factory('Criminals.InfoService', ['$resource', '$translate', 'UtilService', function ($resource, $translate, Util) {

    var criminalUrl = 'api/v1/plugin/ext/criminal';

    var Service = $resource('api/latest/plugin', {}, {

        save: {
            method: 'POST',
            url: criminalUrl,
            cache: false
        },

        get: {
            method: 'GET',
            url: criminalUrl + '/:id',
            cache: false,
            isArray: false
        },

        delete: {
            method: 'DELETE',
            url: criminalUrl + '/:id',
            cache: false
        }
    });

    Service.getCriminal = function (id) {
        return Util.serviceCall({
            service: Service.get,
            param: {
                id: id
            },
            onSuccess: function (data) {
                return data;
            }
        });
    };


    Service.saveCriminal = function (criminalInfo) {
        return Util.serviceCall({
            service: Service.save,
            data: JSOG.encode(criminalInfo),
            onSuccess: function (data) {
                return data;
            }
        });
    };

    Service.deleteCriminal = function (id) {
        return Util.serviceCall({
            service: Service.delete,
            param: {
                id: id
            },
            onSuccess: function (data) {
                return data;
            }
        });
    };

    Service.validateCriminal = function(data) {
        if (Util.isEmpty(data)) {
            return false;
        }
        if (0 >= Util.goodValue(data.id, 0)) {
            return false;
        }
        if (!Util.isArray(data.participants)) {
            return false;
        }
        return true;
    };

    return Service;
}]);

'use strict';

angular.module('criminals').config(['$stateProvider',
    function($stateProvider) {
        $stateProvider.state('criminals', {
            url: '/criminals',
            templateUrl: 'modules/criminals/views/criminals.client.view.html',
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function($translate, $translatePartialLoader){
                    $translatePartialLoader.addPart('criminals');
                    $translatePartialLoader.addPart('common');
                    return $translate.refresh();
                }]
            }
        })

            .state('new-criminal', {
                url: 'new-criminal',
                templateUrl: 'modules/criminals/view/components/dialogs/new-criminal-modal.client.view',
                resolve: {
                    translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                        $translatePartialLoader.addPart('criminals');
                        return $translate.refresh();
                    }]
                }
            })

            .state('criminals.main', {
                url: '/:id/main',
                templateUrl: 'modules/criminals/views/components/criminals-details.client.view.html',
                params: {
                    "type": "CRIMINAL"
                }
            })

            .state('criminals.id', {
                url: '/:id',
                templateUrl: 'modules/criminals/views/criminals.client.view.html'
            })

            .state('criminals.details', {
                url: '/:id/details',
                templateUrl: 'modules/criminals/views/components/criminals-details.client.view.html'
            })

            .state('criminals.history', {
                url: '/:id/history',
                templateUrl: 'modules/common/views/object-history.client.view.html',
                params: {
                    "type": "CRIMINAL"
                }
            })

            .state('criminals.participants', {
                url: '/:id/participants',
                templateUrl: 'modules/criminals/views/components/criminals-participants.client.view.html'
            });
    }
]);

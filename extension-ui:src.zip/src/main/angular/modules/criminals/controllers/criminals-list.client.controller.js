'use strict';

angular.module('criminals').controller('CriminalsListController', ['$scope', '$translate', '$state', '$stateParams', 'UtilService', 'Criminals.ListService', 'Criminals.InfoService', 'Helper.ObjectBrowserService',
        function ($scope, $translate, $state, $stateParams, Util, CriminalsListService, CriminalsInfoService, HelperObjectBrowserService) {

            //"treeConfig", "treeData", "onLoad", and "onSelect" will be set by Tree Helper
            new HelperObjectBrowserService.Tree({
                scope: $scope,
                state: $state,
                stateParams: $stateParams,
                moduleId: "criminals",
                resetTreeData: function () {
                    return CriminalsListService.resetCriminalsTreeData();
                },
                updateTreeData: function (start, n, sort, filters, query, nodeData) {
                    return CriminalsListService.updateCriminalsTreeData(start, n, sort, filters, query, nodeData);
                },
                getTreeData: function (start, n, sort, filters, query) {
                    return CriminalsListService.queryCriminalsTreeData(start, n, sort, filters, query);
                },
                getNodeData: function (criminalId) {
                    return CriminalsInfoService.getCriminal(criminalId);
                },
                makeTreeNode: function (criminal) {
                    return {
                        nodeId: criminal.id,
                        nodeType: $translate.instant("criminals.objectType"),
                        nodeTitle: criminal.criminalTitle,
                        nodeToolTip: criminal.criminalTitle
                    };
                }
            });

        }]);

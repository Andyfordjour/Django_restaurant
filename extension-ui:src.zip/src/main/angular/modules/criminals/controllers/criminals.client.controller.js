'use strict';

angular.module('criminals').controller('CriminalsController', ['$scope', '$translate', '$state', '$stateParams', 'UtilService', 'ConfigService', 'Criminals.InfoService', 'ObjectService', 'Helper.ObjectBrowserService', 'Object.CalendarService',
    function($scope, $translate, $state, $stateParams, Util, ConfigService, CriminalsInfoService, ObjectService, HelperObjectBrowserService, ObjectCalendarService) {

        new HelperObjectBrowserService.Content({
            scope: $scope,
            state: $state,
            stateParams: $stateParams,
            moduleId: "criminals",
            getObjectInfo: CriminalsInfoService.getCriminal,
            updateObjectInfo: CriminalsInfoService.saveCriminal,
            getObjectIdFromInfo: function (criminalInfo) {
                return Util.goodMapValue(criminalInfo, "id");
            },
            getObjectTypeFromInfo: function (objectInfo) {
                return $translate.instant("criminals.objectType");
            }
        });

    }
]);

'use strict';

angular.module('criminals').controller('Criminals.ParticipantsController', ['$scope', '$translate', 'Criminals.InfoService', function ($scope, $translate, CriminalsInfoService) {

    $scope.participantsInit = {
        moduleId: 'criminals',
        componentId: 'participants',
        showReplaceChildrenParticipants: true,
        retrieveObjectInfo: CriminalsInfoService.getCriminal,
        validateObjectInfo: CriminalsInfoService.validateCriminal,
        saveObjectInfo: CriminalsInfoService.saveCriminal,
        objectType: "CRIMINAL",
        participantsTitle: $translate.instant("criminals.comp.participants.title")
    }

}]);

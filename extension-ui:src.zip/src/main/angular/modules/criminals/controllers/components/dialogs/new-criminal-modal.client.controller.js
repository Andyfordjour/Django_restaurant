'use strict';

/**
 * @ngdoc controller
 * @name criminals.controller:NewCriminal.ModalController
 *
 * @description
 * Controls the "New Criminal" popup form (Criminal Title, Criminal Type, Initiator).
 *
 * Two things were fixed/added on this controller so the form actually works end to end:
 *  1. The Criminal Type dropdown used to call a lookup ("criminalTypes") that does not exist
 *     anywhere in the system config, so it was always empty. It now reuses the Complaint
 *     module's "complaintTypes" lookup via {@link ObjectLookupService#getComplaintTypes}.
 *  2. The Initiator field used to be a plain text box. It is now a read-only field that opens
 *     the shared "Add Person" popup (see {@link addPersonInitiator}), the same popup the
 *     Complaint and Case modules use, so the initiator can be picked from an existing person
 *     or created as a brand new one.
 */
angular.module('criminals').controller('NewCriminal.ModalController', ['$scope', '$translate', '$modal', '$modalInstance', 'Criminals.InfoService', 'Object.LookupService', 'Person.InfoService'
    , function ($scope, $translate, $modal, $modalInstance, CriminalsInfoService, ObjectLookupService, PersonInfoService) {

        /**
         * The form model bound to the New Criminal dialog's inputs.
         * Starts empty; the user fills in criminalTitle, criminalType and initiator
         * before the Save button (bound to $scope.save) becomes enabled.
         */
        $scope.newCriminal = {
            criminalTitle: null,
            criminalType: null,
            initiator: null,
            status: null
        };

        /**
         * Populate the Criminal Type dropdown.
         * Reuses the Complaint module's category list ("complaintTypes" lookup) instead of a
         * dedicated "criminalTypes" lookup, per the decision to share one list across modules.
         */
        ObjectLookupService.getComplaintTypes().then(function (criminalTypes) {
            $scope.criminalTypes = criminalTypes;
        });

        /**
         * @ngdoc method
         * @name addPersonInitiator
         * @methodOf criminals.controller:NewCriminal.ModalController
         *
         * @description
         * Opens the shared "Add Person" popup (the same one Complaint/Case use) so the user can
         * either search for an existing Person or create a brand new one to use as the Initiator.
         *
         * `params.types = []` + `hideAssociationTypes: true` tell the popup to hide its
         * "association type" dropdown entirely, because a Criminal's initiator is just a plain
         * name (a String on the backend) - there is no person-type/role concept to pick, unlike
         * Complaint's initiator which is tied to a real person association.
         *
         * When the popup closes, exactly one of two things happened:
         *  - `data.isNew` is true: the user typed a brand new person -> save that new Person
         *    record first, then use the saved name as the initiator.
         *  - `data.isNew` is false: the user picked an existing person from search -> look up
         *    that person's name and use it as the initiator.
         */
        $scope.addPersonInitiator = function () {
            var params = {};
            params.types = [];
            params.typeEnabled = false;
            params.hideAssociationTypes = true;

            var modalInstance = $modal.open({
                scope: $scope,
                animation: true,
                templateUrl: 'modules/common/views/add-person-modal.client.view.html',
                controller: 'Common.AddPersonModalController',
                size: 'md',
                backdrop: 'static',
                resolve: {
                    params: function () {
                        return params;
                    }
                }
            });

            modalInstance.result.then(function (data) {
                if (data.isNew) {
                    // Brand new person: create the Person record first, then use its name.
                    PersonInfoService.savePersonInfoWithPictures(data.person, data.personImages).then(function (response) {
                        $scope.newCriminal.initiator = response.data.givenName + " " + response.data.familyName;
                    });
                } else {
                    // Existing person: fetch full info so we can build the display name.
                    PersonInfoService.getPersonInfo(data.personId).then(function (person) {
                        $scope.newCriminal.initiator = person.givenName + " " + person.familyName;
                    });
                }
            });
        };

        /**
         * Saves the new Criminal and closes the dialog. Disabled in the view until
         * criminalTitle, criminalType and initiator are all filled in (form validation).
         */
        $scope.save = function () {
            CriminalsInfoService.saveCriminal($scope.newCriminal).then(function (newCriminal) {
                $modalInstance.close();
            });
        };

        /** Closes the dialog without saving. */
        $scope.dismiss = function () {
            $modalInstance.dismiss('cancel');
        };

    }
]);

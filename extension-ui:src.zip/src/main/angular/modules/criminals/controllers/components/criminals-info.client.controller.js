'use strict';

/**
 * @ngdoc controller
 * @name criminals.controller:Criminals.InfoController
 *
 * @description
 * Controls the Criminal module's "header" bar - the summary strip shown above the
 * Details/Participants/History tabs, modeled directly on Complaint's header
 * (Complaints.InfoController + complaint-info.client.view.html).
 *
 * Unlike Complaint, a Criminal record has very few fields (no number, priority, assignee,
 * owning group or due date), so this header only shows what actually exists on the backend
 * ExtCriminal model: criminalTitle, status, criminalType, initiator and created date.
 */
angular.module('criminals').controller('Criminals.InfoController', ['$scope', '$stateParams', '$translate', '$modal', 'UtilService', 'Criminals.InfoService', 'Object.LookupService', 'Person.InfoService', 'Helper.ObjectBrowserService',
    function ($scope, $stateParams, $translate, $modal, Util, CriminalsInfoService, ObjectLookupService, PersonInfoService, HelperObjectBrowserService) {

        /**
         * Standard ArkCase wiring: loads the current Criminal into $scope.objectInfo and
         * keeps this header in sync whenever the Details tab (or anything else) saves changes,
         * via the "object-updated" broadcast that Helper.ObjectBrowserService listens for.
         */
        new HelperObjectBrowserService.Component({
            scope: $scope,
            stateParams: $stateParams,
            moduleId: "criminals",
            componentId: "info",
            retrieveObjectInfo: CriminalsInfoService.getCriminal
        });

        /**
         * Builds $scope.dateOut, a date-format string (e.g. "MM/dd/yyyy") derived from the
         * app's configured date format, used by the "Created" date filter in the view.
         * Copied from Complaints.InfoController so dates are formatted consistently
         * across modules.
         */
        var dateDisplayFormat = $translate.instant("common.defaultDateTimeUIFormat").split(' ');
        var dateDisplay = dateDisplayFormat[0].split('/');
        var dataOut = dateDisplay[0] + '/' + dateDisplay[1].toLowerCase() + '/' + dateDisplay[2].toLowerCase();
        $scope.dateOut = dataOut + (dateDisplayFormat[1] !== undefined ? ' ' + dateDisplayFormat[1] : '') + (dateDisplayFormat[2] !== undefined ? ' ' + dateDisplayFormat[2] : '');

        /** Populates the Criminal Type dropdown shown in the header (reuses Complaint's list). */
        ObjectLookupService.getComplaintTypes().then(function (criminalTypes) {
            $scope.criminalTypes = criminalTypes;
        });

        /**
         * @ngdoc method
         * @name addPersonInitiator
         * @methodOf criminals.controller:Criminals.InfoController
         *
         * @description
         * Lets the user change the Initiator directly from the header, without needing to
         * open the Details tab. Same "Add Person" popup as the New Criminal dialog and the
         * Details tab, except here the result is saved immediately (saveCriminal()) since
         * there is no separate "Save" button in the header - each field auto-saves itself.
         */
        $scope.addPersonInitiator = function () {
            var params = {};
            params.types = [];
            params.typeEnabled = false;
            params.hideAssociationTypes = true;

            var modalInstance = $modal.open({
                scope: $scope,
                animation: true,
                templateUrl: 'modules/common/views/add-person-modal.client.view.html',
                controller: 'Common.AddPersonModalController',
                size: 'md',
                backdrop: 'static',
                resolve: {
                    params: function () {
                        return params;
                    }
                }
            });

            modalInstance.result.then(function (data) {
                if (data.isNew) {
                    // Brand new person: create the Person record first, then use its name.
                    PersonInfoService.savePersonInfoWithPictures(data.person, data.personImages).then(function (response) {
                        $scope.objectInfo.initiator = response.data.givenName + " " + response.data.familyName;
                        $scope.saveCriminal();
                    });
                } else {
                    // Existing person: fetch full info so we can build the display name.
                    PersonInfoService.getPersonInfo(data.personId).then(function (person) {
                        $scope.objectInfo.initiator = person.givenName + " " + person.familyName;
                        $scope.saveCriminal();
                    });
                }
            });
        };

        /**
         * @ngdoc method
         * @name saveCriminal
         * @methodOf criminals.controller:Criminals.InfoController
         *
         * @description
         * Saves the header's inline edits (Title, Type, Initiator) and tells the rest of the
         * page ("report-object-updated") that the Criminal changed, so the Details tab and
         * the left-hand tree refresh themselves too.
         */
        $scope.saveCriminal = function () {
            CriminalsInfoService.saveCriminal($scope.objectInfo).then(function (objectInfo) {
                $scope.$emit("report-object-updated", objectInfo);
                return objectInfo;
            }, function (error) {
                $scope.$emit("report-object-update-failed", error);
                return error;
            });
        };
    }
]);

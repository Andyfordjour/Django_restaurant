'use strict';

/**
 * @ngdoc controller
 * @name criminals.controller:Criminals.DetailsController
 *
 * @description
 * Controls the "Details" tab of an existing Criminal (Criminal Title, Criminal Type, Initiator).
 * This is the same fix as the New Criminal popup, applied here too so editing an already-saved
 * Criminal behaves the same way as creating one:
 *  1. Criminal Type dropdown now reuses the Complaint module's "complaintTypes" lookup
 *     (see {@link ObjectLookupService#getComplaintTypes}) instead of a non-existent
 *     "criminalTypes" lookup that always returned an empty list.
 *  2. Initiator is now set through the shared "Add Person" popup (see
 *     {@link addPersonInitiator}) instead of a plain text box.
 */
angular.module('criminals').controller('Criminals.DetailsController', ['$scope', '$stateParams', '$translate', '$modal', 'UtilService', 'ConfigService', 'Criminals.InfoService', 'Object.LookupService', 'Person.InfoService', 'MessageService', 'Helper.ObjectBrowserService',
        function ($scope, $stateParams, $translate, $modal, Util, ConfigService, CriminalsInfoService, ObjectLookupService, PersonInfoService, MessageService, HelperObjectBrowserService) {

            /**
             * Standard ArkCase wiring: loads the Criminal identified by the URL's :id
             * into $scope.objectInfo, and keeps it in sync with the rest of the object
             * browser (tabs, header) via the shared Helper.ObjectBrowserService.
             */
            new HelperObjectBrowserService.Component({
                scope: $scope,
                stateParams: $stateParams,
                moduleId: "criminals",
                componentId: "details",
                retrieveObjectInfo: CriminalsInfoService.getCriminal
            });

            /** Populates the Criminal Type dropdown (see class-level comment above). */
            ObjectLookupService.getComplaintTypes().then(function (criminalTypes) {
                $scope.criminalTypes = criminalTypes;
            });

            /**
             * @ngdoc method
             * @name addPersonInitiator
             * @methodOf criminals.controller:Criminals.DetailsController
             *
             * @description
             * Same "Add Person" popup logic as {@link NewCriminal.ModalController#addPersonInitiator},
             * just writing the result into `$scope.objectInfo.initiator` (the already-saved
             * Criminal being edited) instead of `$scope.newCriminal.initiator`.
             */
            $scope.addPersonInitiator = function () {
                var params = {};
                params.types = [];
                params.typeEnabled = false;
                params.hideAssociationTypes = true;

                var modalInstance = $modal.open({
                    scope: $scope,
                    animation: true,
                    templateUrl: 'modules/common/views/add-person-modal.client.view.html',
                    controller: 'Common.AddPersonModalController',
                    size: 'md',
                    backdrop: 'static',
                    resolve: {
                        params: function () {
                            return params;
                        }
                    }
                });

                modalInstance.result.then(function (data) {
                    if (data.isNew) {
                        // Brand new person: create the Person record first, then use its name.
                        PersonInfoService.savePersonInfoWithPictures(data.person, data.personImages).then(function (response) {
                            $scope.objectInfo.initiator = response.data.givenName + " " + response.data.familyName;
                        });
                    } else {
                        // Existing person: fetch full info so we can build the display name.
                        PersonInfoService.getPersonInfo(data.personId).then(function (person) {
                            $scope.objectInfo.initiator = person.givenName + " " + person.familyName;
                        });
                    }
                });
            };

            /** Persists any edits made on this tab (title, type, initiator, ...). */
            $scope.saveDetails = function () {
                CriminalsInfoService.saveCriminal($scope.objectInfo).then(function (objectInfo) {
                    return objectInfo;
                });
            };
        }]);

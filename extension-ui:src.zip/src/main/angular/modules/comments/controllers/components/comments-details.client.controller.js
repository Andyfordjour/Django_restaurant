'use strict';

angular.module('comments').controller('Comments.DetailsController', ['$scope', '$stateParams', '$translate', 'UtilService', 'ConfigService', 'Comments.InfoService', 'MessageService', 'Helper.ObjectBrowserService',
        function ($scope, $stateParams, $translate, Util, ConfigService, CommentsInfoService, MessageService, HelperObjectBrowserService) {

            new HelperObjectBrowserService.Component({
                scope: $scope,
                stateParams: $stateParams,
                moduleId: "comments",
                componentId: "details",
                retrieveObjectInfo: CommentsInfoService.getComment
            });

            $scope.summernoteOptions = {
                focus: true,
                height: 300,
                toolbar: [
                    ['style', ['bold', 'italic', 'underline', 'clear']],
                    ['font', ['strikethrough', 'superscript', 'subscript']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['height', ['height']]
                ]
            };

            $scope.saveDetails = function () {
                CommentsInfoService.saveComment($scope.objectInfo).then(function (objectInfo) {
                    return objectInfo;
                });
            };
        }]);
'use strict';

angular.module('comments').controller('Comments.ParticipantsController', ['$scope', '$translate', 'Comments.InfoService', function ($scope, $translate, CommentsInfoService) {

    $scope.participantsInit = {
        moduleId: 'comments',
        componentId: 'participants',
        showReplaceChildrenParticipants: true,
        retrieveObjectInfo: CommentsInfoService.getComment,
        validateObjectInfo: CommentsInfoService.validateComment,
        saveObjectInfo: CommentsInfoService.saveComment,
        objectType: "COMMENT",
        participantsTitle: $translate.instant("comments.comp.participants.title")
    }

}]);
'use strict';

angular.module('comments').controller('NewComment.ModalController', ['$scope', '$translate', '$modal', '$modalInstance', 'Search.AutoSuggestService', 'UtilService', 'Util.DateService', 'Comments.InfoService', 'ObjectService', 'ConfigService'
    , function ($scope, $translate, $modal, $modalInstance, AutoSuggestService, UtilService, UtilDateService, CommentsInfoService, ObjectService, ConfigService) {

        var dialogObjectPickerConfig = null;
        ConfigService.getModuleConfig("common").then(function (moduleConfig) {
            dialogObjectPickerConfig = moduleConfig.dialogObjectPicker;
        });

        $scope.newComment = {
            details: null,
            parentId: null,
            parentType: null,
            parentTitle: null,
            status: null
        };

        $scope.summernoteOptions = {
            focus: true,
            height: 300,
            toolbar: [
                ['style', ['bold', 'italic', 'underline', 'clear']],
                ['font', ['strikethrough', 'superscript', 'subscript']],
                ['fontsize', ['fontsize']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['height', ['height']]
            ]
        };

        $scope.pickComplaint = function () {
            var params = {};
            params.header = $translate.instant("common.dialogObjectPicker.header", {
                objectLabel: ObjectService.ObjectTypes.COMPLAINT
            });
            params.filter = '"Object Type": ' + ObjectService.ObjectTypes.COMPLAINT;
            var modalInstance = $modal.open({
                templateUrl: "modules/common/views/object-picker-modal.client.view.html",
                controller: ['$scope', '$modalInstance', 'params', function ($scope, $modalInstance, params) {
                    $scope.modalInstance = $modalInstance;
                    $scope.header = params.header;
                    $scope.filter = params.filter;
                    $scope.config = dialogObjectPickerConfig;
                }],
                animation: true,
                size: 'lg',
                backdrop: 'static',
                resolve: {
                    params: function () {
                        return params;
                    }
                }
            });
            modalInstance.result.then(function (selected) {
                $scope.newComment.parentType = selected.object_type_s;
                $scope.newComment.parentId = selected.object_id_s;
                $scope.newComment.parentTitle = selected.title_parseable_lcs;
            });
        };

        $scope.save = function () {
            CommentsInfoService.saveComment($scope.newComment).then(function (newComment) {
                $modalInstance.close();
            });
        };

        $scope.dismiss = function () {
            $modalInstance.dismiss('cancel');
        };

    }
]);
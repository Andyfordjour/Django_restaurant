'use strict';

angular.module('comments').controller('CommentsController', ['$scope', '$translate', '$state', '$stateParams', 'UtilService', 'ConfigService', 'Comments.InfoService', 'ObjectService', 'Helper.ObjectBrowserService', 'Object.CalendarService',
    function($scope, $translate, $state, $stateParams, Util, ConfigService, CommentsInfoService, ObjectService, HelperObjectBrowserService, ObjectCalendarService) {

        new HelperObjectBrowserService.Content({
            scope: $scope,
            state: $state,
            stateParams: $stateParams,
            moduleId: "comments",
            getObjectInfo: CommentsInfoService.getComment,
            updateObjectInfo: CommentsInfoService.saveComment,
            getObjectIdFromInfo: function (commentInfo) {
                return Util.goodMapValue(commentInfo, "id");
            },
            getObjectTypeFromInfo: function (objectInfo) {
                return $translate.instant("comments.objectType");
            }
        });

    }
]);
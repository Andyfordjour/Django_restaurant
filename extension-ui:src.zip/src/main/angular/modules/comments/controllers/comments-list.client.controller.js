'use strict';

angular.module('comments').controller('CommentsListController', ['$scope', '$translate', '$state', '$stateParams', 'UtilService', 'Comments.ListService', 'Comments.InfoService', 'Helper.ObjectBrowserService',
        function ($scope, $translate, $state, $stateParams, Util, CommentsListService, CommentsInfoService, HelperObjectBrowserService) {

            //"treeConfig", "treeData", "onLoad", and "onSelect" will be set by Tree Helper
            new HelperObjectBrowserService.Tree({
                scope: $scope,
                state: $state,
                stateParams: $stateParams,
                moduleId: "comments",
                resetTreeData: function () {
                    return CommentsListService.resetCommentsTreeData();
                },
                updateTreeData: function (start, n, sort, filters, query, nodeData) {
                    return CommentsListService.updateCommentsTreeData(start, n, sort, filters, query, nodeData);
                },
                getTreeData: function (start, n, sort, filters, query) {
                    return CommentsListService.queryCommentsTreeData(start, n, sort, filters, query);
                },
                getNodeData: function (commentId) {
                    return CommentsInfoService.getComment(commentId);
                },
                makeTreeNode: function (comment) {
                    return {
                        nodeId: comment.id,
                        nodeType: $translate.instant("comments.objectType"),
                        nodeTitle: "Complaint ID " + comment.parentId + " (Comment Date " + comment.created + ")",
                        nodeToolTip: "Complaint ID " + comment.parentId + " (Comment Date " + comment.created + ")"
                    };
                }
            });

        }]);
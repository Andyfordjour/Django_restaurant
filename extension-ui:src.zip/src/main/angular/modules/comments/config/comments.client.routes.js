'use strict';

angular.module('comments').config(['$stateProvider',
    function($stateProvider) {
        $stateProvider.state('comments', {
            url: '/comments',
            templateUrl: 'modules/comments/views/comments.client.view.html',
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function($translate, $translatePartialLoader){
                    $translatePartialLoader.addPart('comments');
                    $translatePartialLoader.addPart('common');
                    return $translate.refresh();
                }]
            }
        })

            .state('new-comment', {
                url: 'new-comment',
                templateUrl: 'modules/comments/view/components/dialogs/new-comment-modal.client.view',
                resolve: {
                    translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                        $translatePartialLoader.addPart('comments');
                        return $translate.refresh();
                    }]
                }
            })

            .state('comments.main', {
                url: '/:id/main',
                templateUrl: 'modules/comments/views/components/comments-details.client.view.html',
                params: {
                    "type": "COMMENT"
                }
            })

            .state('comments.id', {
                url: '/:id',
                templateUrl: 'modules/comments/views/comments.client.view.html'
            })

            .state('comments.details', {
                url: '/:id/details',
                templateUrl: 'modules/comments/views/components/comments-details.client.view.html'
            })

            .state('comments.history', {
                url: '/:id/history',
                templateUrl: 'modules/common/views/object-history.client.view.html',
                params: {
                    "type": "COMMENT"
                }
            })

            .state('comments.participants', {
                url: '/:id/participants',
                templateUrl: 'modules/comments/views/components/comments-participants.client.view.html'
            });
    }
]);
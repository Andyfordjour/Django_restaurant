'use strict';

angular.module('services').factory('Comments.ListService', ['$resource', '$translate', 'Acm.StoreService', 'UtilService', 'ObjectService', 'Object.ListService', function ($resource, $translate, Store, Util, ObjectService, ObjectListService) {
    var Service = $resource('api/latest/plugin', {}, {});

    Service.SessionCacheNames = {};
    Service.CacheNames = {
        COMMENT_LIST: "CommentList"
    };

    Service.resetCommentsTreeData = function () {
        var cacheCommentList = new Store.CacheFifo(Service.CacheNames.COMMENT_LIST);
        cacheCommentList.reset();
    };

    Service.updateCommentsTreeData = function (start, n, sort, filters, query, nodeData) {
        ObjectListService.updateObjectTreeData(Service.CacheNames.COMMENT_LIST, start, n, sort, filters, query, nodeData);
    };

    Service.queryCommentsTreeData = function (start, n, sort, filters, query, nodeMaker) {
        var param = {};
        param.objectType = $translate.instant("comments.objectType");
        param.start = Util.goodValue(start, 0);
        param.n = Util.goodValue(n, 32);
        /*param.sort = Util.goodValue(sort);
        param.filters = Util.goodValue(filters);*/
        param.query = Util.goodValue(query);

        var cacheCommentList = new Store.CacheFifo(Service.CacheNames.COMMENT_LIST);
        var cacheKey = param.start + "." + param.n + "." + param.sort + "." + param.filters + "." + param.query;
        var treeData = cacheCommentList.get(cacheKey);

        return Util.serviceCall({
            service: ObjectListService._queryObjects,
            param: param,
            result: treeData,
            onSuccess: function (data) {
                treeData = {
                    docs: [],
                    total: data.response.numFound
                };
                var docs = data.response.docs;
                _.forEach(docs, function (doc) {
                    var node;
                    if (nodeMaker) {
                        node = nodeMaker(doc);
                    } else {
                        node = {
                            nodeId: Util.goodValue(doc.object_id_s, 0),
                            nodeType: $translate.instant("comments.objectType"),
                            nodeTitle: Util.goodValue(doc.title_parseable_lcs),
                            nodeToolTip: Util.goodValue(doc.title_parseable_lcs)
                        };
                    }
                    treeData.docs.push(node);
                });
                cacheCommentList.put(cacheKey, treeData);
                return treeData;
            }
        });
    };

    return Service;
}]);
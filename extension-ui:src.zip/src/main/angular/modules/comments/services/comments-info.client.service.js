'use strict';

angular.module('services').factory('Comments.InfoService', ['$resource', '$translate', 'UtilService', function ($resource, $translate, Util) {

    var commentUrl = 'api/v1/plugin/ext/comment';

    var Service = $resource('api/latest/plugin', {}, {

        save: {
            method: 'POST',
            url: commentUrl,
            cache: false
        },

        get: {
            method: 'GET',
            url: commentUrl + '/:id',
            cache: false,
            isArray: false
        },

        delete: {
            method: 'DELETE',
            url: commentUrl + '/:id',
            cache: false
        }
    });

    Service.getComment = function (id) {
        return Util.serviceCall({
            service: Service.get,
            param: {
                id: id
            },
            onSuccess: function (data) {
                return data;
            }
        });
    };


    Service.saveComment = function (commentInfo) {
        return Util.serviceCall({
            service: Service.save,
            data: JSOG.encode(commentInfo),
            onSuccess: function (data) {
                return data;
            }
        });
    };

    Service.deleteComment = function (id) {
        return Util.serviceCall({
            service: Service.delete,
            param: {
                id: id
            },
            onSuccess: function (data) {
                return data;
            }
        });
    };

    Service.validateComment = function(data) {
        if (Util.isEmpty(data)) {
            return false;
        }
        if (0 >= Util.goodValue(data.id, 0)) {
            return false;
        }
        if (!Util.isArray(data.participants)) {
            return false;
        }
        return true;
    };

    return Service;
}]);